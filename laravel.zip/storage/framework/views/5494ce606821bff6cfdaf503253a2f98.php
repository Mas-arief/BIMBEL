<!DOCTYPE html>
<html>
<head>
    <title>List Barang</title>
</head>
<body>
    <h1>List Barang</h1>
    <p>ID Barang: <?php echo e($id); ?></p>
    <p>Nama Barang: <?php echo e($nama); ?></p>
</body>
</html><?php /**PATH D:\laravel\BIMBEL\resources\views/list_barang.blade.php ENDPATH**/ ?>