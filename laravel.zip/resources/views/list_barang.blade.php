<!DOCTYPE html>
<html>
<head>
    <title>List Barang</title>
</head>
<body>
    <h1>List Barang</h1>
    <p>ID Barang: {{ $id }}</p>
    <p>Nama Barang: {{ $nama }}</p>
</body>
</html>